import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-layout',
  templateUrl: './app-user-layout.component.html',
  styleUrls: [
    ]
})
export class AppUserLayoutComponent implements OnInit 
{

  constructor() { }

  ngOnInit() {
  
  }

}