export class ActivePlanModel {
    public PlanID: string;
    public PlanName: string;
}