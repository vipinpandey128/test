export class LoginModel
{
    public Username: string = "";
    public Password: string = "";
}