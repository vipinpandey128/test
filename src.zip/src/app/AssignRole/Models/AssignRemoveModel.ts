export class AssignRemoveModel
{
    public UserId: number;
    public RoleId : number;
}