export class AssignRolesViewModel
{
    public UserId: number;
    public RoleId : number;
    public UserName: string;
    public RoleName :string;
    public UserRolesId: number;
}