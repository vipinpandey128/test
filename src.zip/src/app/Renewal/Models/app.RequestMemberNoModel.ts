export class RequestMemberNoModel 
{
    public MemberNo: string;
}