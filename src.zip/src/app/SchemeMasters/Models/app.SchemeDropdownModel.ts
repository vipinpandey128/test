export class SchemeDropdownModel {
    public SchemeID: string = "";
    public SchemeName: string = "";
}