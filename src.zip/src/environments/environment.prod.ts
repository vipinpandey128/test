export const environment = {
  production: true,
  apiEndpoint: 'https://localhost:44319'
};
